function sayHello(name){
  console.log('Hello ' + name);
}
sayHello('samra');
//console.log(window)
