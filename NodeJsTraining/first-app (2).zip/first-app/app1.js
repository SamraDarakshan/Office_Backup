/* var sayHello = function () {
}

window.sayHello();*/
//console.log(module);
var s = require('./Logger');
//lo('samra'); // we can put object also or call directly see word document
// how to pass this logger.endPoint();

//s("samra");
//console.log(s.func("samra"));
console.log(s("samra"));
s ("2nd method");

//
