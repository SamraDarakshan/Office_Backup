
  console.log(__filename);
  console.log(__dirname);
//var url ='http://mylogger.io/log';

function func(message){
  //send an http request
  //console.log(message);
  return message;
};

function abc(msg){
  console.log(msg)
};

module.exports=func;
module.exports=abc;
//module.exports.endPoint=url;
