exports.myDateTime = function () {
    return Date();
};
module.exports = Date();
