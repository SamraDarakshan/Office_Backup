document.body.style.backgroundColor= 'green'
alert('samra')
