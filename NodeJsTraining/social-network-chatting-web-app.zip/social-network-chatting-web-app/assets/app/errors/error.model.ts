export class MyError {
    constructor(public title: string, public message: string) {}
}